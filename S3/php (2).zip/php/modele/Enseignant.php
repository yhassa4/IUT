<?php
include_once("modele.php");
    class Enseignant extends Modele{

        protected static $objet = "enseignant";
        protected static $cle = "NumEnsei";
        
        protected int $NumEnsei;
        protected string $NomEnsei;
        protected string $PrenomEnsei;
        protected string $GenreEnsei;
        protected string $emaMailProEnseiil;
        protected string $MailPersoEnsei;
        protected string $AdrrEnsei;
        protected int $Numrole;

        
       

        
        public function afficher () {
            echo "<p>Utilisateur $this->nom ($this->prenom $this->nom), email = $this->email</p>";
        }

    }
?>