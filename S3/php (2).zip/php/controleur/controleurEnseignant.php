<?php
    
    require_once("modele/Enseignant.php");
    require_once("./config/connexion.php");
    Connexion::connect();

    //def de controleur voiture
    class ControleurEnseignant extends Controleur{
        

        protected static $objet = "enseignant";
        protected static $cle = "login";
        

          
    
        
    }
    ?>