<?php
    
    require_once("modele/Sondage.php");
    require_once("./config/connexion.php");
    Connexion::connect();

    //def de controleur voiture
    class ControleurSondage extends Controleur{
        

        protected static $objet = "Sondage";
        protected static $cle = "login";
    }
    ?>