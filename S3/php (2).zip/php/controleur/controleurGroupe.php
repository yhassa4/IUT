<?php
    
    require_once("modele/Groupe.php");
    require_once("./config/connexion.php");
    Connexion::connect();

    //def de controleur voiture
    class ControleurGroupe extends Controleur{
        

        protected static $objet = "Groupe";
        protected static $cle = "login";
    }
    ?>