<!DOCTYPE html>
<html lang="fr">
<div class="page-container">
    <header class="top-bar">
        <div class="universite-info">
             <img src="path/to/logo.png" alt="Université Paris-Saclay">
             <span>IUT D'ORSAY</span>
        </div>
        <div class="user-info">
             <span>Promotion 1</span>
             <span>Paul Pierre</span>
             <a href="#" class="btn-responsable">Responsables</a>
             <a href="routeur.php?action=deconnexion" class="btn-deconnexion">Déconnexion</a>
        </div>
    </header>

    <div class="main-menu-bar">
        <div class="menu-tabs">
            <a class="tab <?php echo (isset($ongletActif) && $ongletActif == 'vue') ? 'active' : ''; ?>" href="routeur.php?action=vue_ensemble">Vue d'ensemble</a>
            <a class="tab <?php echo (isset($ongletActif) && $ongletActif == 'enseignant') ? 'active' : ''; ?>" href="routeur.php?action=lireEnseignant">Enseignant</a>
            <a class="tab <?php echo (isset($ongletActif) && $ongletActif == 'groupe') ? 'active' : ''; ?>" href="routeur.php?action=lireGroupe">Groupe</a>
            <a class="tab <?php echo (isset($ongletActif) && $ongletActif == 'sondage') ? 'active' : ''; ?>" href="routeur.php?action=lireSondage">Sondage</a>
            <a class="tab <?php echo (isset($ongletActif) && $ongletActif == 'etudiant') ? 'active' : ''; ?>" href="routeur.php?action=lireEtudiant">Etudiant</a>
        </div>
    </div>
    
    <div class="stats-cards">
        <div class="card">
            <h3>Étudiants</h3>
            <h1><?php echo count($lesEtudiants); ?></h1>
        </div>
        <div class="card">
            <h3>Groupes</h3>
            <h1>0</h1>
        </div>
        <div class="card">
            <h3>Promotions</h3>
            <h1>2</h1>
        </div>
    </div>
    
    <div class="table-controls">
        <div class="filter-area">
            <select name="groupe">
                <option>Aucun Group</option>
                </select>
            <input type="text" placeholder="Nom">
            <button class="search-btn"></button>
        </div>
        
        <a class="bouton-primaire" href="routeur.php?action=ajouterEtudiant">ajouter etudiant</a>
    </div>

    <table class="students-table">
        <thead>
            <tr>
                <th>Id Etudiant</th>
                <th>Nom Prénom</th>
                <th>Genre</th>
                <th>Type Bac</th>
                <th>Statut</th>
                <th>Groupe</th>
                <th>Actions</th>
            </tr>
        </thead>
    </table>