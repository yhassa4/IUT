<?php
include_once("modele.php");
    class Etudiant extends Modele{

        protected static $objet = "Etudiant";
        protected static $cle = "NumEtu";
        
        protected int $NumEtu;
        protected string $NomEtu;
        protected string $PrenomEtu;
        protected string $GenreEtu;
        protected string $MailProEtu;
        protected string $MailPersoEtu;
        protected string $AddrEtu;
        protected int $NumBac;
        protected int $NumPromo;
        protected int $NumGroup;
        protected int $Numparcour;

        
       

       
        
        public function afficher () {
            //echo "<p>Utilisateur $this->nom ($this->prenom $this->nom), email = $this->email</p>";
        }

       
    }
?>