<?php
include_once("modele.php");
    class Enseignant extends Modele{

        protected static $objet = "ensignant";
        protected static $cle = "NumEnsei";
        
        protected int $NumEnsei;
        protected string $NomEnsei;
        protected string $PrenomEnsei;
        protected string $GenreEnsei;
        protected string $emaMailProEnseiil;
        protected string $MailPersoEnsei;
        protected string $AdrrEnsei;
        protected int $Numrole;

        
       

        
        

        public static function getAllWithRoles() {
                $sql = "SELECT e.*, r.nomrole 
                        FROM ensignant e 
                        JOIN Role r ON e.numrole = r.numrole";
                $st = Connexion::pdo()->query($sql);
                $st->setFetchMode(PDO::FETCH_CLASS, 'enseignant');
                return $st->fetchAll();
            }

        public static function countResponsables() {
            // On fait une jointure pour lier l'enseignant à son nom de rôle
            $sql = "SELECT COUNT(*) 
                    FROM ensignant e 
                    INNER JOIN Role r ON e.numrole = r.numrole 
                    WHERE r.nomRole LIKE '%Responsable%'";
                    
            $st = Connexion::pdo()->query($sql);
            return (int)$st->fetchColumn();
        }

        // Dans modele/Enseignant.php
        public function afficher() {
            echo "<h3>Détails de l'enseignant</h3>";
            echo "<ul>";
            echo "<li>Numéro : " . $this->NumEnsei . "</li>";
            echo "<li>Nom : " . $this->NomEnsei . "</li>";
            echo "<li>Prénom : " . $this->PrenomEnsei . "</li>";
            echo "<li>Email Pro : " . $this->emaMailProEnseiil . "</li>"; // Attention à la typo ici aussi
            echo "</ul>";
        }

    }
?>