<?php
include_once("modele.php");
    class Sondage extends Modele{

        protected static $objet = "Sondage";
        protected static $cle = "Numsondage";
        
        protected int $Numsondage;
        protected String  $nomsondage;
        protected String $typesondage;
        protected int $NumPromo;
        protected int $NumEnsei;
        
      

    
        
        public function afficher () {
            //echo "<p>Utilisateur $this->nom ($this->prenom $this->nom), email = $this->email</p>";
        }

       
    }
?>