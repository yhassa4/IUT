<div class="content-container">
    <div class="stats-grid">
        <div class="stat-card-big"><h3>Sondage En Cours</h3><div class="number"><?php echo $nbEnCours; ?></div></div>
        <div class="stat-card-big"><h3>Sondage Terminer</h3><div class="number"><?php echo $nbTermines; ?></div></div>
        <div class="stat-card-big"><h3>Sondage Total</h3><div class="number"><?php echo $nbTotal; ?></div></div>
    </div>

    <div class="main-management-grid">
        <div class="creation-panel survey-creation">
            <h2>Creation</h2>
            <form action="routeur.php?controleur=controleurSondage&action=creer" method="post">
                <div class="survey-flex">
                    <div class="survey-left-col">
                        <label>Titre</label>
                        <input type="text" name="titre" class="input-styled">

                        <label>Sondage Simple :</label>
                        <div class="radio-group">
                            <input type="radio" name="simple" checked>  <input type="radio" name="simple"> 
                        </div>

                        <label>Date De Fin :</label>
                        <div class="date-inputs">
                            <input type="text" placeholder="jj"> <input type="text" placeholder="mm"> <input type="text" placeholder="aaaa">
                        </div>

                        <label>Promotion :</label>
                        <select class="promo-select-full">
                            <option>Promotion 1</option>
                            <option>Promotion 2</option>
                        </select>
                    </div>

                    <div class="survey-right-col">
                        <button type="button" class="btn-grey-small">Ajouter Une Nouvelle Question</button>
                        <div class="question-box">
                            <div class="question-header"><span>Question 1</span> </div>
                            <textarea placeholder="Votre question..."></textarea>
                        </div>
                        
                        <label>Envoyer Un Mail :</label>
                        <div class="radio-group">
                            <input type="radio" name="mail" checked> Oui <input type="radio" name="mail"> Non
                        </div>
                        <button type="submit" class="btn-cree">Cree</button>
                    </div>
                </div>
            </form>
        </div>

        <div class="list-panel">
            <table class="survey-list-table">
                <thead>
                    <tr>
                        <th>Nom</th>
                        <th>Status</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($lesSondages as $s): ?>
                    <tr>
                        <td><?php echo $s->get('titreSondage'); ?></td>
                        <td><?php echo $s->get('etat'); ?></td>
                        <td>🔍</td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>