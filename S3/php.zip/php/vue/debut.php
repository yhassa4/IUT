<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des Groupes</title>
    <link rel="stylesheet" href="./css/styleMenu.css">
</head>
<body>

    <div class="top-header">
        <div class="logo-univ">Université PARIS-SACLAY</div>
        <div class="iut-text">IUT D'ORSAY</div>
    </div>

    <div class="title-bar">
        <div class="app-title">
            <span>🎓 Plateforme De Gestion Des Groupes</span>
        </div>
        
        <div class="user-nav">
            <div class="promo-badge">Promotion 1 ⌵</div>
            <span class="user-name">Paul Pierre</span>
            <a href="#" class="role-badge">Responsables</a>
            <a href="routeur.php?action=deconnexion" class="logout-btn">Deconnexion</a>
        </div>
    </div>

    <div class="menu-container">
        <div class="nav-pills">
            <?php $c = $_GET['controleur'] ?? ''; ?>
            <a href="routeur.php?controleur=controleurGlobal&action=accueil" class="nav-link">Vue D'ensemble</a>
            <a href="routeur.php?controleur=controleurEnseignant&action=lireObjets" class="nav-link <?php echo (strpos($c, 'Enseignant')) ? 'active' : ''; ?>">Enseignant</a>
            <a href="routeur.php?controleur=controleurGroupe&action=lireObjets" class="nav-link">Groupe</a>
            <a href="routeur.php?controleur=controleurSondage&action=lireObjets" class="nav-link <?php echo (strpos($c, 'Sondage')) ? 'active' : ''; ?>">Sondage</a>
            <a href="routeur.php?controleur=controleurEtudiant&action=lireObjets" class="nav-link <?php echo (strpos($c, 'Etudiant')) ? 'active' : ''; ?>">Etudiant</a>
        </div>
    </div>

    <div class="content-body">
       