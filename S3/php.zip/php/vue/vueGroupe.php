<div class="content-container">
    <div class="stats-grid">
        <div class="stat-card-big"><h3>Étudiants</h3><div class="number"><?php echo $nbEtudiants; ?></div></div>
        <div class="stat-card-big"><h3>Redoublant/Excep</h3><div class="number"><?php echo $nbRedoublants; ?></div></div>
        <div class="stat-card-big"><h3>Apprentie</h3><div class="number"><?php echo $nbApprentis; ?></div></div>
    </div>

    <div class="main-management-grid">
        
        <div class="creation-panel">
            <h2>Creation</h2>
            <form action="routeur.php?controleur=controleurGroupe&action=creer" method="post">
                <div class="form-section">
                    <label>Étudiants Par Classe :</label>
                    <input type="text" name="nbEtu">
                    <br />
                    <label>Classe Mixte :</label>
                    <div class="radio-group">
                        <input type="radio" name="mixte" checked> Oui <input type="radio" name="mixte"> Non
                    </div>

                    <label>Respecter Les Contraintes :</label>
                    <div class="radio-group">
                        <input type="radio" name="contrainte" checked> Oui <input type="radio" name="contrainte"> Non
                    </div>

                    <label>Date De Publication :</label>
                    <div class="date-inputs">
                        <input type="text" placeholder="m"> <input type="text" placeholder="j"> <input type="text" placeholder="H">
                    </div>
                </div>
                <button type="submit" class="btn-valider">Valider</button>
            </form>
        </div>

        <div class="list-panel">
            <div class="list-header">Liste Groupe : Promotion 1</div>
            <div class="group-items">
                <?php foreach($lesGroupes as $g): ?>
                <div class="group-row">
                    <span><?php echo $g->get('nomGroupe'); ?></span>
                    <div class="row-icons">👁️ ⚙️</div>
                </div>
                <?php endforeach; ?>
            </div>
            <div class="list-footer">
                <button class="btn-add-group">ajouter un group</button>
                <div class="footer-actions">
                    <button class="btn-publier">Publier</button>
                    <button class="btn-annuler">Annuler</button>
                </div>
            </div>
        </div>
    </div>
</div>