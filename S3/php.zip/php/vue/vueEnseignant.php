<div class="content-container">
    <div class="stats-grid-small">
        <div class="stat-card-white">
            <h3>Professeur</h3>
            <div class="big-num"><?php echo $nbTotal; ?></div>
        </div>
        <div class="stat-card-white">
            <h3>Professeur Total Filière</h3>
            <div class="big-num"><?php echo $nbResponsables; ?></div>
        </div>
    </div>

    <div class="action-bar">
        <select class="promo-select">
            <option>Groupe 1</option>
        </select>
        
        <button id="openModal" class="btn-add">Ajouter Enseignant</button>
    </div>

    <div id="addTeacherModal" class="modal">
        <div class="modal-content">
            <span class="close-btn">&times;</span>
            <h2 style="text-align:center; font-size: 24px;">Ajout Professeur</h2>
            
            <form action="routeur.php?controleur=controleurEnseignant&action=creer" method="post" class="modal-form">
                <div class="input-group">
                    <label>Nom :</label>
                    <input type="text" name="nom" required>
                </div>

                <div class="input-group">
                    <label>Prenom :</label>
                    <input type="text" name="prenom" required>
                </div>

                <div class="input-group">
                    <label>Genre :</label>
                    <select name="genre">
                        <option value="M">Masculin</option>
                        <option value="F">Féminin</option>
                    </select>
                </div>

                <div class="input-group">
                    <label>Matiere :</label>
                    <select name="matiere">
                        <option value="Maths">Maths</option>
                        <option value="Java">Java</option>
                        <option value="Python">Python</option>
                        <option value="C++">C++</option>
                    </select>
                </div>

                <div class="input-group">
                    <label>Role :</label>
                    <select name="numrole">
                        <option value="1">Enseignant</option>
                        <option value="2">Responsable Filière</option>
                        <option value="3">Responsable CM</option>
                    </select>
                </div>

                <button type="submit" class="btn-submit-modal">Valider</button>
            </form>
        </div>
    </div>

    <table class="teacher-table">
        <thead>
            <tr>
                <th>Id Professeur</th>
                <th>Nom Prénom</th>
                <th>Genre</th>
                <th>Matiere</th>
                <th>Statut</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($aff as $l) echo $l; ?>
        </tbody>
    </table>
</div>

<script>
    var modal = document.getElementById("addTeacherModal");
    var btn = document.getElementById("openModal");
    var span = document.getElementsByClassName("close-btn")[0];

    btn.onclick = function() { modal.style.display = "block"; }
    span.onclick = function() { modal.style.display = "none"; }
    window.onclick = function(event) {
        if (event.target == modal) { modal.style.display = "none"; }
    }
</script>