<div class="dashboard-wrapper">
    <div class="stats-grid">
        <div class="stat-card-big">
            <h3>Étudiants</h3>
            <div class="number"><?php echo $nbEtudiants; ?></div>
        </div>

        <div class="stat-card-big">
            <h3>Sondage En Cours</h3>
            <div class="number">0</div>
        </div>

        <div class="stat-card-big">
            <h3>Enseignant</h3>
            <div class="number"><?php echo $nbEnseignants; ?></div>
        </div>

        <div class="stat-card-big">
            <h3>Promotions</h3>
            <div class="number"><?php echo $nbPromotions; ?></div>
        </div>
    </div>

    <div class="sondage-preview">
        <h3>Sondage 1</h3>
        <p></p>
        <p></p>
        
    </div>
</div>