<?php 
require_once("./config/connexion.php");
Connexion::connect();

require_once("controleur/controleur.php");

// 1. Définition des valeurs par défaut
$controleur = "controleurEtudiant";
$action = "lireObjets"; // Nom correct de la méthode dans ton Controleur parent

// 2. Liste blanche des contrôleurs (attention à la casse !)


$tableauControleurs = [
    "controleurEnseignant", 
    "controleurEtudiant", 
    "controleurGroupe", 
    "controleurPromotion", 
    "controleurSondage", 
    "controleurGlobal"
];

// 3. Vérification du contrôleur
if(isset($_GET["controleur"]) && in_array($_GET["controleur"], $tableauControleurs)){
    $controleur = $_GET["controleur"];
}

// Chargement du fichier
require_once("controleur/$controleur.php");

// 4. Vérification de l'action
if(isset($_GET["action"]) && in_array($_GET["action"], get_class_methods($controleur))){
    $action = $_GET["action"];
} else {
    // Si l'action n'est pas précisée ou n'existe pas, on affiche la liste par défaut
    $action = "lireObjets"; 
}

// 5. Appel de la méthode statique
$controleur::$action();
?>