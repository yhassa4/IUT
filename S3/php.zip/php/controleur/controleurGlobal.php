<?php
require_once("controleur/controleur.php");
require_once("modele/Etudiant.php");
require_once("modele/Enseignant.php");
require_once("modele/Groupe.php");

class controleurGlobal extends Controleur {

    public static function accueil() {
        $titre = "Vue d'ensemble";
        
        // On utilise la nouvelle fonction count() de chaque modèle
        $nbEtudiants = etudiant::count();
        $nbEnseignants = enseignant::count();
        $nbGroupes = groupe::count();
        $nbPromotions = 2; 

        include("vue/debut.php");
        include("vue/vueEnsemble.php"); 
        include("vue/fin.html");
    }
}
?>