<?php
    
    require_once("modele/Groupe.php");
    require_once("./config/connexion.php");
    require_once("modele/Etudiant.php");

    Connexion::connect();

    //def de controleur voiture
    class ControleurGroupe extends Controleur{
        

        protected static $objet = "Group_";
        protected static $cle = "NumGroup";

        public static function lireObjets() {
        $titre = "Gestion des Groupes";

        // 1. Stats pour les cartes du haut
        $nbEtudiants = etudiant::count();
        $nbRedoublants = 0; //redoublement::count(); a faire 
        $nbApprentis = 0;   

        // 2. Liste des groupes pour le tableau de droite
        $lesGroupes = Groupe::getAll();

        include("vue/debut.php");
        include("vue/vueGroupe.php");
        include("vue/fin.html");
    }

    public static function creer() {
        $nbEtuParClasse = $_POST['nbEtu'];
        $donnees = array(
            'nomGroupe' => "Groupe " . (groupe::count() + 1),
            'capacite' => $nbEtuParClasse
        );
        groupe::save($donnees);
        self::lireObjets();
    }
    }
    ?>