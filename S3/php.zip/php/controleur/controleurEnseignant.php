<?php
    
    require_once("modele/Enseignant.php");
    require_once("./config/connexion.php");
    Connexion::connect();

    //def de controleur voiture
    class ControleurEnseignant extends Controleur{
        

        protected static $objet = "ensignant";
        protected static $cle = "NumEnsei";

        public static function lireObjets() {
            $titre = "Gestion des Enseignants";

            // 1. Chiffres automatiques
            $nbTotal = enseignant::count(); // Utilise la méthode générique de Modele
            $nbResponsables = enseignant::countResponsables();

            // 2. Liste avec jointure pour avoir le nom du rôle
            $lesObjet = enseignant::getAllWithRoles();

            // 3. Construction des lignes du tableau
            $aff = array(); 
            foreach ($lesObjet as $ob) {
                $ligne = "<tr>";
                $ligne .= "<td><b>" . $ob->get('idProfesseur') . "</b></td>";
                $ligne .= "<td>" . $ob->get('nom') . " " . $ob->get('prenom') . "</td>";
                $ligne .= "<td>" . $ob->get('genre') . "</td>";
                $ligne .= "<td>" . $ob->get('matiere') . "</td>";
                // On utilise 'nomrole' qui vient de la jointure
                $ligne .= "<td>" . $ob->get('nomrole') . "</td>"; 
                $ligne .= "<td>⚙️</td>";
                $ligne .= "</tr>";
                $aff[] = $ligne;
            }

            include("vue/debut.php");
            include("vue/vueEnseignant.php");
            include("vue/fin.html");
        }

        public static function getAllWithRoles() {
            $requete = "SELECT e.*, r.nomrole 
                    FROM ensignant e 
                    JOIN role r ON e.numrole = r.numrole";
            $resultat = Connexion::pdo()->query($sql);
            $resultat->setFetchMode(PDO::FETCH_CLASS, 'ensignant');
            return $resultat->fetchAll();
        }

        public static function creer() {
            
            $donnees = array(
                'NomEnsei' => $_POST['nom'],
                'PrenomEnsei' => $_POST['prenom'],
                //'matiere' => $_POST['matiere'],
                'Numrole' => $_POST['numrole']
            );
            enseignant::save($donnees);
            self::lireObjets(); // Recharge la page avec le nouveau prof
        }
        

          
    
        
    }
    ?>