<?php
    
    require_once("modele/Sondage.php");
    require_once("./config/connexion.php");
    Connexion::connect();

    //def de controleur voiture
    class ControleurSondage extends Controleur{
        

        protected static $objet = "Sondage";
        protected static $cle = "Numsondage";

        public static function lireObjets() {
        $titre = "Gestion des Sondages";

        // 1. Statistiques pour les cartes
        // Tu peux créer des méthodes count() spécifiques dans ton modèle plus tard
        $nbEnCours = 6; // 
        $nbTermines = 10;
        $nbTotal = $nbEnCours + $nbTermines;

        // 2. Liste des sondages pour le tableau de droite
        $lesSondages = sondage::getAll();

        include("vue/debut.php");
        include("vue/vueSondage.php");
        include("vue/fin.html");
    }

    public static function creer() {
        // 1. Enregistrer le sondage
        $idSondage = sondage::save([
            'titreSondage' => $_POST['titre'],
            'etat' => 'En cours',
            'dateFin' => $_POST['dateFin']
        ]);

        // 2. Enregistrer chaque question reliée à ce sondage
        if (!empty($_POST['questions'])) {
            foreach ($_POST['questions'] as $texte) {
                // On suppose qu'il existe un modele 'question'
                question::save([
                    'idSondage' => $idSondage,
                    'texteQuestion' => $texte
                ]);
            }
        }
        self::lireObjets();
    }
    }
    ?>