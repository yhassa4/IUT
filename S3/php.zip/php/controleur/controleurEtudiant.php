<?php
    
    require_once("modele/Etudiant.php");
    require_once("./config/connexion.php");
    Connexion::connect();

    //def de controleur voiture
    class controleurEtudiant extends Controleur{
        

        protected static $objet = "etudiant";
        protected static $cle = "login";
    }
    ?>