<?php 
require_once("modele/modele.php");
require_once("modele/Etudiant.php");
require_once("modele/Enseignant.php");

session_start(); 

require_once("./config/connexion.php");
Connexion::connect();

require_once("controleur/controleur.php");
require_once("controleur/controleurConnexion.php");

// def variable
$controleur = $_GET["controleur"] ?? "controleurConnexion";
$action = $_GET["action"] ?? "afficherPage";
$tableauControleurs = ["controleurEnseignant", "controleurEtudiant", "controleurGroupe", "controleurPromotion", "controleurSondage", "controleurGlobal", "controleurConnexion"];

// connexion
$actions_publiques = ["afficherPage", "connecter"];
if (!isset($_SESSION['user']) && !in_array($action, $actions_publiques)) {
    header("Location: routeur.php?controleur=controleurConnexion&action=afficherPage");
    exit();
}

if (isset($_SESSION['role'])) {
    $role = $_SESSION['role'];
    
   
    $liste_responsables = [
        1, 2, 3, 4, 
        '1', '2', '3', '4',
        'Responsable semestre', 
        'Responsable d annee', 
        'Responsable de fillieres', 
        'Responsable de formation', 
        'admin'
    ];

    $is_responsable = in_array($role, $liste_responsables);

    // pour etudiant
    if ($role === 'etudiant') {
        $actions_etu = ["mesNotes", "mesGroupes", "voirPromotion", "afficherCovoiturage", "enregistrerCovoiturage", "repondre", "voter", "accueil"];
        if ($controleur === "controleurEtudiant" || $controleur === "controleurGlobal") {
            if (!in_array($action, $actions_etu)) {
                $action = "accueil"; 
                $controleur = "controleurGlobal";
            }
        }
    }

    // pour responsable et Enseignants
    else if ($is_responsable) {
        // Autorisation spécifique pour l'importation de notes
        if ($controleur === "controleurEtudiant" && ($action === "afficherFormulaireImport" || $action === "importerNotes")) {
        }
        
        // Restriction Enseignants 
        else {
        // Restriction Enseignants : Seul le rôle 4 ou admin peut modifier les profs
        $is_super_admin = ($role == 4 || $role == '4' || $role === 'Responsable de formation' || $role === 'admin');
        if ($controleur === "controleurEnseignant" && !$is_super_admin) {
            $actions_admin_prof = ["creer", "modifier", "supprimer", "enregistrer", "afficherFormulaire"];
            if (in_array($action, $actions_admin_prof)) {
                $controleur = "controleurGlobal";
                $action = "accueil";
            }
            }
        }
    }
}

// chargement des fichier controleur
if(in_array($controleur, $tableauControleurs)){
    require_once("controleur/$controleur.php");
} else {
    $controleur = "controleurGlobal";
    require_once("controleur/$controleur.php");
}

// verif methode et execution
if(!method_exists($controleur, $action)){
    $action = (isset($_SESSION['user'])) ? "accueil" : "afficherPage";
    $controleur = (isset($_SESSION['user'])) ? "controleurGlobal" : "controleurConnexion";
    require_once("controleur/$controleur.php");
}

$controleur::$action();
?>