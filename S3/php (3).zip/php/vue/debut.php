<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title><?php echo $titre ?? 'Gestion des Groupes'; ?></title>
    <link rel="stylesheet" href="./css/styleMenu.css">
</head>
<body>

    <div class="top-header">
        <div class="logo-univ">Université PARIS-SACLAY</div>
        <div class="iut-text">IUT D'ORSAY</div>
    </div>

    <div class="title-bar">
        <div class="app-title">
            <span>🎓 Plateforme De Gestion Des Groupes</span>
        </div>
        
        <div class="user-nav">
            <?php if (isset($_SESSION['user'])): ?>
                <div class="promo-badge">
                    <?php 
                        // Affiche la promo pour l'étudiant, sinon Administration
                        echo $_SESSION['role'] === 'etudiant' ? 'Promo ' . $_SESSION['user']->get('NumPromo') : 'Administration'; 
                    ?> ⌵
                </div>

                <span class="user-name">
                    <?php 
                        if ($_SESSION['role'] === 'etudiant') {
                            echo htmlspecialchars($_SESSION['user']->get('Prenometu') . ' ' . $_SESSION['user']->get('Nometu'));
                        } else {
                            echo htmlspecialchars($_SESSION['user']->get('PrenomEnsei') . ' ' . $_SESSION['user']->get('NomEnsei'));
                        }
                    ?>
                </span>

                <span class="role-badge"><?php echo ucfirst($_SESSION['role']); ?></span>
                
                <a href="routeur.php?controleur=controleurConnexion&action=deconnecter" class="logout-btn">Deconnexion</a>
            <?php endif; ?>
        </div>
    </div>

    <?php 
   
    if (isset($_SESSION['role']) && ($_SESSION['role'] === 'responsable' || $_SESSION['role'] === 'admin')): 
    ?>
    <div class="menu-container">
        <div class="nav-pills">
            <?php $c = $_GET['controleur'] ?? 'controleurGlobal'; ?>
            
            <a href="routeur.php?controleur=controleurGlobal&action=accueil" 
               class="nav-link <?php echo ($c == 'controleurGlobal') ? 'active' : ''; ?>">Vue D'ensemble</a>
            
            <?php if ($_SESSION['role'] === 'admin'): ?>
                <a href="routeur.php?controleur=controleurEnseignant&action=lireObjets" 
                   class="nav-link <?php echo ($c == 'controleurEnseignant') ? 'active' : ''; ?>">Enseignants</a>
            <?php endif; ?>
            
            <a href="routeur.php?controleur=controleurGroupe&action=lireObjets" 
               class="nav-link <?php echo ($c == 'controleurGroupe') ? 'active' : ''; ?>">Groupes</a>
            
            <a href="routeur.php?controleur=controleurSondage&action=lireObjets" 
               class="nav-link <?php echo ($c == 'controleurSondage') ? 'active' : ''; ?>">Sondages</a>
            
            <a href="routeur.php?controleur=controleurEtudiant&action=lireObjets" 
               class="nav-link <?php echo ($c == 'controleurEtudiant') ? 'active' : ''; ?>">Étudiants</a>
        </div>
    </div>
    <?php endif; ?>

    <div class="content-body">
        
        <?php if (isset($_GET['msg']) || isset($_GET['error'])): ?>
            <div class="notification-area">
                
                <?php if (isset($_GET['msg']) && $_GET['msg'] == 'vote_ok'): ?>
                    <div class="alert alert-success">
                        <span>✅</span> Votre vote a été enregistré avec succès !
                    </div>
                <?php endif; ?>

                <?php if (isset($_GET['error']) && $_GET['error'] == 'expire'): ?>
                    <div class="alert alert-danger">
                        <span>⚠️</span> Désolé, ce sondage est fermé (date limite dépassée).
                    </div>
                <?php endif; ?>
                
                <?php if (isset($_GET['msg']) && $_GET['msg'] == 'supprime'): ?>
                    <div class="alert alert-info">
                        <span>🗑️</span> Le sondage a bien été supprimé.
                    </div>
                <?php endif; ?>

            </div>
        <?php endif; ?>