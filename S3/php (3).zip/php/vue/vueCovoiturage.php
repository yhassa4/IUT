<div class="content-container">
    <div class="stat-card-white">
        <h3>🚗 Mon Groupe de Covoiturage</h3>
        [cite_start]<p>Indiquez les numéros étudiants de vos collègues (2 à 4 personnes max)[cite: 20].</p>
        
        <form action="routeur.php?controleur=controleurEtudiant&action=enregistrerCovoiturage" method="post" class="modal-form">
            <div id="inputs-container">
                <label>Collègue 1 (Numéro Étudiant) :</label>
                <input type="number" name="collegues[]" required>
                
                <label>Collègue 2 (Numéro Étudiant) :</label>
                <input type="number" name="collegues[]" required>
            </div>
            
            <button type="button" onclick="ajouterChamp()" class="btn-search" style="margin-top:10px;">+ Ajouter un collègue</button>
            <button type="submit" class="btn-submit-modal" style="margin-top:20px;">Enregistrer le groupe</button>
        </form>
    </div>
</div>

<script>
function ajouterChamp() {
    const container = document.getElementById('inputs-container');
    const nbInputs = container.querySelectorAll('input').length;
    if (nbInputs < 4) {
        const label = document.createElement('label');
        label.innerText = `Collègue ${nbInputs + 1} (Numéro Étudiant) :`;
        const input = document.createElement('input');
        input.type = 'number';
        input.name = 'collegues[]';
        container.appendChild(label);
        container.appendChild(input);
    } else {
        alert("Limite de 4 collègues maximum atteinte.");
    }
}
</script>