 <?php 
 
    
     $v->afficher();
        

    ?>