<?php
    require_once("modele/Etudiant.php");
    require_once("modele/Groupe.php");    
    require_once("modele/Promotion.php"); 
    require_once("./config/connexion.php");
    
    Connexion::connect();

    class controleurEtudiant extends Controleur {
        
        protected static $objet = "Etudiant";
        protected static $cle = "Numetu";

        public static function lireObjets() {
        
            $nbEtudiants = etudiant::count(); 
            $nbGroupes = groupe::count(); 
            $nbPromotions = promotion::count(); 
            $lesEtudiants = etudiant::getAll();
            $aff = [];
            
            foreach($lesEtudiants as $e) {
                // On prépare les données pour la vue
                $statut = ($e->get('apprentissage') == 1) ? "Apprentissage" : "Initial";
                
                $ligne = "<tr>";
                $ligne .= "<td>" . $e->get('Numetu') . "</td>";
                $ligne .= "<td>" . $e->get('Nometu') . " " . $e->get('Prenometu') . "</td>";
                $ligne .= "<td>" . $e->get('GenreEtu') . "</td>";
                $ligne .= "<td> Bac " . $e->get('NumBac') . "</td>";
                $ligne .= "<td>" . $statut . "</td>";
                $ligne .= "<td> Groupe " . $e->get('NumGroup') . "</td>";
                $ligne .= "<td>" . $e->get('MailPersoEtu') . "</td>";
                
                $ligne .= "</tr>";
                $aff[] = $ligne;
            }

            include("vue/debut.php");
            include("vue/vueEtudiant.php");
            include("vue/fin.html");
        }

       public static function creer() {
            $nom = $_POST['nomEtu'];
            $prenom = $_POST['prenomEtu'];

            $data = array(
                'Nometu'        => $nom,
                'Prenometu'     => $prenom,
                'GenreEtu'      => $_POST['genreEtu'],
                'NumBac'        => (int)$_POST['typeBac'],
                'apprentissage' => ($_POST['statutEtu'] == "Apprentissage") ? 1 : 0,
                'MailProEtu'    => strtolower($prenom.".".$nom."@univ.fr"), 
                'MailPersoEtu'  => $_POST['MailPersoEtu'],
                'AddrEtu'       => $_POST['AddrEtu'],
                'password'      => password_hash($_POST['password'], PASSWORD_DEFAULT),              
                'NumPromo'      => (int)$_POST['NumPromo'],
                'NumGroup'      => (int)$_POST['NumGroup'],
                'Numparcour'    => (int)$_POST['Numparcour']
            );

            etudiant::save($data);

            header("Location: routeur.php?controleur=controleurEtudiant&action=lireObjets");
            exit();
        }

        public static function enregistrerCovoiturage() {
            $monId = $_SESSION['user']->get('Numetu');
            $collegues = $_POST['collegues'];

            foreach ($collegues as $idCollegue) {
                if (!empty($idCollegue) && $idCollegue != $monId) {
                    // On insère dans ta table covoiture
                    $sql = "INSERT IGNORE INTO covoiture (Numetu, Numetu_1) VALUES (?, ?)";
                    Modele::executeRequete($sql, [$monId, $idCollegue]);
                }
            }
            header("Location: routeur.php?controleur=controleurGlobal&action=accueil");
        }

        
    }
?>