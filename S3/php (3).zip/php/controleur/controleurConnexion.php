<?php
require_once("modele/Etudiant.php");
require_once("modele/Enseignant.php");

class controleurConnexion {

    public static function afficherPage() {
        $titre = "Connexion";
        include("vue/debut.php");
        include("vue/vueConnexion.php");
        include("vue/fin.html");
    }

    public static function connecter() {
        $login = $_POST['login'];
        $mdp = $_POST['mdp'];
        $user = Enseignant::getByIdentifiant($login);
        if ($user && ($mdp == $user->get('password') || password_verify($mdp, $user->get('password')))) {
            $_SESSION['user'] = $user;
            $numRole = (int)$user->get('Numrole');

            if ($numRole >= 1 && $numRole <= 3) {
                $_SESSION['role'] = 'responsable'; 
                header("Location: routeur.php?controleur=controleurGlobal&action=accueil");
            } 
            elseif ($numRole == 4) {
                $_SESSION['role'] = 'admin'; 
                header("Location: routeur.php?controleur=controleurGlobal&action=accueil");
            } 
            else {
                $_SESSION['role'] = 'enseignant';
                header("Location: routeur.php?controleur=controleurEtudiant&action=lireObjets");
            }
            exit();
        }

        $user = Etudiant::getByIdentifiant($login);
        if ($user && ($mdp == $user->get('password') || password_verify($mdp, $user->get('password')))) {
            $_SESSION['user'] = $user;
            $_SESSION['role'] = 'etudiant';
            header("Location: routeur.php?controleur=controleurGlobal&action=accueil");
            exit();
        }
        
        header("Location: routeur.php?controleur=controleurConnexion&action=afficherPage&error=1");
    }

    public static function deconnecter() {
        session_destroy();
        header("Location: routeur.php");
    }
}
?>