<?php 
require_once("modele/modele.php");
require_once("modele/Etudiant.php");
require_once("modele/Enseignant.php");

session_start(); 

require_once("./config/connexion.php");
Connexion::connect();

require_once("controleur/controleur.php");
require_once("controleur/controleurConnexion.php");

$actions_publiques = ["afficherPage", "connecter"];

$actions_de_gestion = ["creer", "modifier", "supprimer", "enregistrer", "afficherFormulaire", "importer", "exporter"];

$controleurs_gestion = ["controleurEnseignant", "controleurEtudiant", "controleurGroupe", "controleurPromotion", "controleurSondage"];

$controleur = $_GET["controleur"] ?? "controleurConnexion";
$action = $_GET["action"] ?? "afficherPage";

$tableauControleurs = ["controleurEnseignant", "controleurEtudiant", "controleurGroupe", "controleurPromotion", "controleurSondage", "controleurGlobal", "controleurConnexion"];

if (!isset($_SESSION['user']) && !in_array($action, $actions_publiques)) {
    header("Location: routeur.php?controleur=controleurConnexion&action=afficherPage");
    exit();
}


if (isset($_SESSION['role'])) {
    $role = $_SESSION['role']; 

    //  ÉTUDIANT 
    if ($role === 'etudiant') {
        // Liste des contrôleurs interdits sauf exception
        if (in_array($controleur, $controleurs_gestion)) {
            
            // EXCEPTION : On autorise l'étudiant à aller sur le contrôleur Sondage
            // mais SEULEMENT pour les actions 'repondre' et 'voter'
            $actionsAutoriseesEtu = ["repondre", "voter"];
            
            if ($controleur === "controleurSondage" && in_array($action, $actionsAutoriseesEtu)) {
                // On laisse passer (ne rien faire)
            } else {
                // Sinon, on redirige vers l'accueil
                $controleur = "controleurGlobal";
                $action = "accueil";
            }
        }
    }

    //  ENSEIGNANT CLASSIQUE 
    if ($role === 'enseignant') {
        if (in_array($action, $actions_de_gestion)) {
            $action = "lireObjets";
        }
    }

    //  RESPONSABLE (1, 2, 3) 
    if ($role === 'responsable') {
        if ($controleur === "controleurEnseignant") {
            $controleur = "controleurGlobal";
            $action = "accueil";
        }
    }
}

// CHARGEMENT ET VÉRIFICATION DU CONTRÔLEUR
if(in_array($controleur, $tableauControleurs)){
    require_once("controleur/$controleur.php");
} else {
    $controleur = "controleurGlobal";
    require_once("controleur/$controleur.php");
}

//  VÉRIF DE LA MÉTHODE 
if(!method_exists($controleur, $action)){
    $action = (isset($_SESSION['user'])) ? "accueil" : "afficherPage"; 
}
$controleur::$action();
?>